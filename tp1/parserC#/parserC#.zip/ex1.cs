// Hello, world program
// This program writes "hello, world" to the console
//
class Hello // any name will do for this class
{

  class Class1
  {
    static void Test(bool \u0066)
    {
      char c = '\u0066';
      if (\u0066)
      {
        System.Console.WriteLine(c.ToString());
      }
    }
  }

  static void Main() // this method must be named "Main"
  {
    System.Console.WriteLine("hello, world");
  }
}