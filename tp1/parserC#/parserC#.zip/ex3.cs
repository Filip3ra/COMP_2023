ulong hex1 = 0x12345678UL;
ulong hex2 = 0xA5UL;
ulong hex3 = 0xF0F0UL;
ulong hex4 = 0xFFFF_FFFF_FFFF_FFFFUL;